import { CommonModule } from '@angular/common';
import { Component, OnDestroy, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subscription, interval } from 'rxjs';

import { AppSetting, Appointment, AuditEvent, AuthUser, DeviceEndpoint, DisplayState, Doctor, Holiday, LookupOption, Patient, PermissionDefinition, QueueReport, QueueToken, RealtimeStatus, RoleDefinition, ScheduleSlot, SmsMessage, View, WaitingRoom } from './models';
import { QueueApiService } from './queue-api.service';
import { RealtimeService } from './realtime.service';

const EMPTY_DOCTOR: Doctor = { id: '', name: 'No radiographer configured', department: '—', room: '—', waitingRoom: '' };

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnDestroy {
  private readonly api = inject(QueueApiService);
  private readonly realtime = inject(RealtimeService);
  private refreshSubscription?: Subscription;
  private realtimeSubscription?: Subscription;
  private statusSubscription?: Subscription;

  doctors: Doctor[] = [];
  waitingRooms: WaitingRoom[] = [];

  view: View = 'reception';
  selectedDoctorId = '';
  selectedWaitingRoom = '';
  tokens: QueueToken[] = [];
  displayState: DisplayState | null = null;
  report: QueueReport | null = null;
  auditEvents: AuditEvent[] = [];
  settings: AppSetting[] = [];
  settingsTab: 'general' | 'account' | 'users' | 'roles' | 'master-data' | 'operations' = 'general';
  passwordForm = { current: '', next: '', confirm: '' };
  passwordBusy = false;
  audioTestBusy = false;
  busy = false;
  message = '';
  lastSpokenTokenId = '';
  realtimeStatus: RealtimeStatus = 'offline';
  currentUser: AuthUser | null = null;
  authChecked = false;
  loginBusy = false;
  loginError = '';
  showLoginPassword = false;
  isRefreshing = false;
  dataStatus: 'online' | 'offline' = 'online';
  lastSyncedAt: Date | null = null;
  loginForm = { username: '', password: '' };
  users: AuthUser[] = [];
  roles: RoleDefinition[] = [];
  permissionCatalog: PermissionDefinition[] = [];
  selectedRoleName = '';
  showRoleCreator = false;
  newRole = { name: '', display_name: '', access_profile: 'reception', description: '', permissions: [] as string[] };
  newUser = { username: '', full_name: '', password: '', role: 'reception', doctor_id: '' };
  form = { patient_title: '', patient_name: '', patient_phone: '', service_category: '', rank: '', service_number: '', priority: '' };
  printToken: QueueToken | null = null;
  lookupOptions: LookupOption[] = [];
  lookupCategories = ['department', 'patient_title', 'sex', 'service_category', 'rank_relationship', 'priority_category'];
  selectedLookupCategory = 'patient_title';
  newLookup = { category: 'patient_title', value: '', label: '', sort_order: 0 };
  holidays: Holiday[] = [];
  newHoliday = { holiday_date: '', name: '' };
  devices: DeviceEndpoint[] = [];
  newDevice = { name: '', device_type: 'display', waiting_room: '' };
  smsMessages: SmsMessage[] = [];
  patients: Patient[] = [];
  appointments: Appointment[] = [];
  appointmentSlots: ScheduleSlot[] = [];
  allAppointmentSlots: ScheduleSlot[] = [];
  rescheduleSlots: Record<string, string> = {};
  patientSearch = '';
  appointmentDoctorId = '';
  appointmentForm = { patient_id: '', slot_id: '', reason: '', notes: '' };
  newPatient = { name: '', mobile: '', title: '', sex: '' };

  constructor() {
    this.api.session().subscribe({
      next: (user) => {
        this.currentUser = user;
        this.authChecked = true;
        if (user) this.initialize();
      },
      error: () => { this.authChecked = true; },
    });
  }

  private initialize(): void {
    // Initialization may run after both a restored session and an explicit login.
    // Keep exactly one polling timer so repeated initialization cannot multiply
    // background requests.
    this.refreshSubscription?.unsubscribe();
    const requestedView = new URLSearchParams(window.location.search).get('view');
    const defaultView: View = this.hasPermission('pages.radiographer') ? 'doctor'
      : this.hasPermission('pages.reception') ? 'reception'
      : this.hasPermission('pages.reports') ? 'reports'
      : this.hasPermission('pages.display') ? 'display'
      : 'settings';
    this.view = defaultView;
    if (requestedView === 'reception' || requestedView === 'doctor' || requestedView === 'reports' || requestedView === 'settings' || requestedView === 'display') {
      if (this.canView(requestedView)) this.view = requestedView;
    }
    this.refresh();
    this.api.listDoctors().subscribe({
      next: (doctors) => {
        if (!doctors.length) return;
        this.doctors = doctors;
        const assigned = this.currentUser?.doctor_id
          ? doctors.find((doctor) => doctor.id === this.currentUser?.doctor_id)
          : undefined;
        this.selectedDoctorId = assigned?.id || (doctors.some((doctor) => doctor.id === this.selectedDoctorId) ? this.selectedDoctorId : doctors[0].id);
        if (!doctors.some((doctor) => doctor.id === this.appointmentDoctorId)) this.appointmentDoctorId = doctors[0].id;
        this.doctorChanged();
      },
    });
    this.api.listWaitingRooms().subscribe({ next: (rooms) => {
      this.waitingRooms = rooms;
      if (!rooms.some((room) => room.code === this.selectedWaitingRoom)) this.selectedWaitingRoom = rooms[0]?.code || '';
      if (!this.newDevice.waiting_room) this.newDevice.waiting_room = rooms[0]?.code || '';
      if (this.view === 'display' && this.selectedWaitingRoom) {
        this.refresh();
        this.connectRealtime();
      }
    } });
    this.refreshSubscription = interval(5000).subscribe(() => {
      if (document.visibilityState === 'visible') this.refresh();
    });
    this.statusSubscription = this.realtime.status$.subscribe((status) => this.realtimeStatus = status);
    if (this.view === 'display') this.connectRealtime();
    if (this.view === 'reports') { this.api.report().subscribe((report) => this.report = report); this.api.audit().subscribe((events) => this.auditEvents = events); }
    if (this.view === 'settings') this.loadSettings();
    if (this.hasPermission('users.view')) {
      this.api.users().subscribe((users) => this.users = users);
    }
    if (this.hasPermission('roles.view')) {
      this.api.roles().subscribe((roles) => {
        this.roles = roles;
        if (!roles.some((role) => role.name === this.selectedRoleName)) this.selectedRoleName = roles[0]?.name || '';
      });
      this.api.permissions().subscribe((permissions) => this.permissionCatalog = permissions);
    }
    this.loadLookups();
  }

  ngOnDestroy(): void {
    this.refreshSubscription?.unsubscribe();
    this.realtimeSubscription?.unsubscribe();
    this.statusSubscription?.unsubscribe();
  }

  login(): void {
    this.loginBusy = true;
    this.loginError = '';
    this.api.login(this.loginForm.username.trim(), this.loginForm.password).subscribe({
      next: (user) => {
        this.currentUser = user;
        this.loginBusy = false;
        this.loginForm.password = '';
        this.initialize();
      },
      error: (error) => {
        this.loginError = error?.error?.detail || 'Login failed.';
        this.loginBusy = false;
      },
    });
  }

  logout(): void {
    this.api.logout().subscribe({ complete: () => window.location.reload() });
  }

  canView(view: View): boolean {
    if (!this.currentUser) return false;
    if (view === 'settings') return true;
    if (view === 'reception') return this.hasPermission('pages.reception');
    if (view === 'appointments') return false;
    if (view === 'doctor') return this.hasPermission('pages.radiographer');
    if (view === 'reports') return this.hasPermission('pages.reports');
    if (view === 'display') return this.hasPermission('pages.display');
    return false;
  }

  get isAdmin(): boolean {
    return (this.currentUser?.access_profile || this.currentUser?.role) === 'admin'
      || !!this.currentUser?.permissions?.includes('settings.manage');
  }

  hasPermission(permission: string): boolean {
    return (this.currentUser?.access_profile || this.currentUser?.role) === 'admin'
      || !!this.currentUser?.permissions?.includes(permission)
      || !!this.currentUser?.permissions?.includes('*');
  }

  get selectedRole(): RoleDefinition | undefined {
    return this.roles.find((role) => role.name === this.selectedRoleName);
  }

  get permissionGroups(): string[] {
    return [...new Set(this.permissionCatalog.map((permission) => permission.group))];
  }

  permissionsForGroup(group: string): PermissionDefinition[] {
    return this.permissionCatalog.filter((permission) => permission.group === group);
  }

  canViewOperations(): boolean {
    return ['holidays.view', 'holidays.manage', 'devices.view', 'devices.manage', 'sms.view', 'sms.retry']
      .some((permission) => this.hasPermission(permission));
  }

  createUser(): void {
    const payload = { ...this.newUser, doctor_id: this.roleProfile(this.newUser.role) === 'radiographer' ? this.newUser.doctor_id || null : null };
    this.api.createUser(payload).subscribe({
      next: (user) => {
        this.users = [...this.users, user].sort((a, b) => a.username.localeCompare(b.username));
        this.newUser = { username: '', full_name: '', password: '', role: 'reception', doctor_id: '' };
        this.message = `${user.username} created.`;
      },
      error: (error) => this.message = error?.error?.detail || 'Could not create user.',
    });
  }

  roleProfile(name: string): string {
    return this.roles.find((role) => role.name === name)?.access_profile || name;
  }

  toggleUser(account: AuthUser): void {
    this.api.updateUser(account.id, { is_active: !account.is_active }).subscribe({
      next: (updated) => this.users = this.users.map((item) => item.id === updated.id ? updated : item),
      error: (error) => this.message = error?.error?.detail || 'Could not update account.',
    });
  }

  updateUserRole(account: AuthUser, role: string): void {
    const definition = this.roles.find((item) => item.name === role);
    const doctorId = definition?.access_profile === 'radiographer' ? account.doctor_id || null : null;
    this.api.updateUser(account.id, { role, doctor_id: doctorId }).subscribe({
      next: (updated) => this.users = this.users.map((item) => item.id === updated.id ? updated : item),
      error: (error) => this.message = error?.error?.detail || 'Could not assign role.',
    });
  }

  deleteUser(account: AuthUser): void {
    if (!window.confirm(`Delete account ${account.username}?`)) return;
    this.api.deleteUser(account.id).subscribe({
      next: () => this.users = this.users.filter((item) => item.id !== account.id),
      error: (error) => this.message = error?.error?.detail || 'Could not delete account.',
    });
  }

  createRole(): void {
    this.api.createRole(this.newRole).subscribe({
      next: (role) => {
        this.roles = [...this.roles, role].sort((a, b) => a.display_name.localeCompare(b.display_name));
        this.selectedRoleName = role.name;
        this.showRoleCreator = false;
        this.newRole = { name: '', display_name: '', access_profile: 'reception', description: '', permissions: [] };
      },
      error: (error) => this.message = error?.error?.detail || 'Could not create role.',
    });
  }

  saveRole(role: RoleDefinition): void {
    this.api.updateRole(role.name, { display_name: role.display_name, access_profile: role.access_profile, description: role.description, permissions: role.permissions }).subscribe({
      error: (error) => this.message = error?.error?.detail || 'Could not save role.',
    });
  }

  toggleRolePermission(role: RoleDefinition, permission: string, enabled: boolean): void {
    role.permissions = enabled
      ? [...new Set([...role.permissions, permission])].sort()
      : role.permissions.filter((item) => item !== permission);
  }

  toggleNewRolePermission(permission: string, enabled: boolean): void {
    this.newRole.permissions = enabled
      ? [...new Set([...this.newRole.permissions, permission])].sort()
      : this.newRole.permissions.filter((item) => item !== permission);
  }

  deleteRole(role: RoleDefinition): void {
    if (!window.confirm(`Delete role ${role.display_name}?`)) return;
    this.api.deleteRole(role.name).subscribe({
      next: () => this.roles = this.roles.filter((item) => item.name !== role.name),
      error: (error) => this.message = error?.error?.detail || 'Could not delete role.',
    });
  }

  resetPassword(account: AuthUser): void {
    if (!this.hasPermission('users.password.reset')) return;
    const password = window.prompt(`New password for ${account.username} (10+ characters):`)?.trim();
    if (!password) return;
    this.api.resetUserPassword(account.id, password).subscribe({
      next: () => this.message = `Password updated for ${account.username}.`,
      error: (error) => this.message = error?.error?.detail || 'Could not reset password.',
    });
  }

  get selectedDoctor(): Doctor {
    return this.doctors.find((doctor) => doctor.id === this.selectedDoctorId) ?? this.doctors[0] ?? EMPTY_DOCTOR;
  }

  get waiting(): QueueToken[] {
    return this.tokens.filter((token) => token.status === 'waiting');
  }

  get current(): QueueToken | undefined {
    return this.tokens.find((token) => ['called', 'recalled', 'in_progress'].includes(token.status));
  }

  get activeQueue(): QueueToken[] { return this.tokens.filter((token) => ['waiting', 'called', 'recalled', 'skipped', 'in_progress'].includes(token.status)); }

  get missingTokenFields(): string[] {
    const missing: string[] = [];
    if (this.form.patient_name.trim().length < 2) missing.push('patient name');
    if (!this.form.service_category) missing.push('service category');
    if (!this.form.priority) missing.push('priority');
    if (!this.selectedDoctorId) missing.push('consulting doctor');
    if (!this.selectedWaitingRoom) missing.push('waiting room');
    return missing;
  }

  setView(view: View): void {
    if (!this.canView(view)) return;
    this.view = view;
    this.message = '';
    const url = new URL(window.location.href);
    url.searchParams.set('view', view);
    window.history.replaceState({}, '', url);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.refresh();
    if (view === 'display') this.connectRealtime();
    else this.realtimeSubscription?.unsubscribe();
    if (view === 'reports') { this.api.report().subscribe((report) => this.report = report); this.api.audit().subscribe((events) => this.auditEvents = events); }
    if (view === 'settings') {
      this.settingsTab = this.hasPermission('settings.manage') ? 'general'
        : this.hasPermission('master_data.manage') ? 'master-data'
        : this.canViewOperations() ? 'operations'
        : 'account';
      this.loadSettings();
    }
  }

  doctorChanged(): void {
    this.refresh();
    if (this.view === 'display') this.connectRealtime();
  }

  waitingRoomChanged(): void {
    this.refresh();
    this.connectRealtime();
  }

  createToken(): void {
    const patientName = this.form.patient_name.trim();
    if (patientName.length < 2) {
      this.message = 'Patient name must contain at least 2 characters.';
      return;
    }
    if (!this.form.service_category) {
      this.message = 'Select a service category.';
      return;
    }
    if (!this.form.priority) {
      this.message = 'Select a priority category.';
      return;
    }
    const doctor = this.selectedDoctor;
    if (!doctor.id) {
      this.message = 'No active radiographer is configured.';
      return;
    }
    if (!this.selectedWaitingRoom) {
      this.message = 'No active waiting room is configured.';
      return;
    }
    this.busy = true;
    this.api.createToken({
      ...this.form,
      patient_title: this.form.patient_title || '',
      patient_name: patientName,
      patient_phone: this.form.patient_phone.trim(),
      rank: this.form.rank || '',
      service_number: this.form.service_number.trim(),
      doctor_id: doctor.id,
      doctor_name: doctor.name,
      department: doctor.department,
      room_number: doctor.room,
      waiting_room: this.selectedWaitingRoom,
      source: 'walk_in',
    }).subscribe({
      next: (token) => {
        this.message = `${token.token_number} generated and added to ${doctor.name}'s live queue.`;
        this.form.patient_name = '';
        this.form.patient_phone = '';
        this.form.rank = '';
        this.form.service_number = '';
        this.busy = false;
        this.refresh();
      },
      error: (error) => {
        this.message = this.apiErrorMessage(error, 'Could not generate the token.');
        this.busy = false;
      },
    });
  }

  private apiErrorMessage(error: any, fallback: string): string {
    const detail = error?.error?.detail;
    if (typeof detail === 'string') return detail;
    if (Array.isArray(detail)) {
      return detail.map((item: any) => {
        const field = Array.isArray(item?.loc) ? item.loc.filter((part: unknown) => part !== 'body').join(' → ') : '';
        return `${field ? field.replaceAll('_', ' ') + ': ' : ''}${item?.msg || 'Invalid value'}`;
      }).join('. ');
    }
    return fallback;
  }

  printSlip(token: QueueToken): void {
    this.printToken = token;
    window.setTimeout(() => {
      window.print();
      this.printToken = null;
    });
  }

  loadLookups(): void {
    this.api.lookups(this.hasPermission('master_data.manage')).subscribe((items) => {
      this.lookupOptions = items;
      this.form.service_category ||= this.lookup('service_category')[0]?.value || '';
      this.form.priority ||= this.lookup('priority_category').find((item) => item.value === 'normal')?.value || this.lookup('priority_category')[0]?.value || '';
    });
  }

  lookup(category: string, activeOnly = true): LookupOption[] {
    return this.lookupOptions.filter((item) => item.category === category && (!activeOnly || item.is_active))
      .sort((a, b) => a.sort_order - b.sort_order || a.label.localeCompare(b.label));
  }

  lookupLabel(category: string, value?: string | null): string {
    if (!value) return '';
    return this.lookupOptions.find((item) => item.category === category && item.value === value)?.label || value;
  }

  createLookup(): void {
    this.newLookup.category = this.selectedLookupCategory;
    const label = this.newLookup.label.trim();
    const value = (this.newLookup.value.trim() || label).toLowerCase().replace(/[^a-z0-9._-]+/g, '_');
    if (!value || !label) return;
    this.api.createLookup({ ...this.newLookup, value, label, metadata_json: {} }).subscribe({
      next: (item) => {
        this.lookupOptions = [...this.lookupOptions, item];
        this.newLookup = { ...this.newLookup, value: '', label: '', sort_order: item.sort_order + 1 };
        this.message = `${item.label} added to ${item.category.replaceAll('_', ' ')}.`;
      },
      error: (error) => this.message = error?.error?.detail || 'Could not add dropdown value.',
    });
  }

  toggleLookup(item: LookupOption): void {
    this.api.updateLookup(item.id, { is_active: !item.is_active }).subscribe({
      next: (updated) => this.lookupOptions = this.lookupOptions.map((value) => value.id === updated.id ? updated : value),
      error: (error) => this.message = error?.error?.detail || 'Could not update dropdown value.',
    });
  }

  renameLookup(item: LookupOption): void {
    const label = window.prompt('Display label:', item.label)?.trim();
    if (!label || label === item.label) return;
    this.api.updateLookup(item.id, { label }).subscribe({
      next: (updated) => this.lookupOptions = this.lookupOptions.map((value) => value.id === updated.id ? updated : value),
      error: (error) => this.message = error?.error?.detail || 'Could not rename dropdown value.',
    });
  }

  callNext(): void {
    this.busy = true;
    this.api.callNext(this.selectedDoctorId).subscribe({
      next: (token) => this.afterCall(token),
      error: (error) => { this.message = error?.error?.detail || 'No waiting patient found.'; this.busy = false; },
    });
  }

  call(token: QueueToken): void {
    this.busy = true;
    this.api.call(this.selectedDoctorId, token.id).subscribe({
      next: (called) => this.afterCall(called),
      error: () => { this.message = 'Unable to call this patient.'; this.busy = false; },
    });
  }

  complete(token: QueueToken): void {
    this.api.action(this.selectedDoctorId, token.id, 'complete').subscribe({
      next: () => { this.message = `${token.token_number} completed.`; this.refresh(); },
      error: () => this.message = 'Unable to complete this consultation.',
    });
  }

  queueAction(token: QueueToken, action: string): void {
    const needsReason = ['skip', 'no_show', 'cancel'].includes(action);
    const reason = needsReason ? window.prompt(`Reason to ${action.replace('_', ' ')} ${token.token_number}:`)?.trim() : undefined;
    if (needsReason && !reason) return;
    this.api.action(this.selectedDoctorId, token.id, action, reason).subscribe({
      next: () => { this.message = `${token.token_number} ${action.replace('_', ' ')} recorded.`; this.refresh(); },
      error: (error) => this.message = error?.error?.detail || 'Action could not be completed.',
    });
  }

  transferPatient(token: QueueToken): void {
    const destinations = this.doctors.filter((doctor) => doctor.id !== token.doctor_id);
    const choices = destinations.map((doctor, index) => `${index + 1}. ${doctor.name} — ${doctor.department}`).join('\n');
    const selection = Number(window.prompt(`Transfer ${token.token_number} to:\n${choices}`));
    const doctor = destinations[selection - 1];
    if (!doctor) return;
    const reason = window.prompt('Transfer reason:')?.trim();
    if (!reason) return;
    this.api.transferToken(token.id, doctor.id, reason).subscribe({
      next: (updated) => { this.message = `${updated.token_number} transferred to ${doctor.name}.`; this.refresh(); },
      error: (error) => this.message = error?.error?.detail || 'Transfer failed.',
    });
  }

  togglePriority(token: QueueToken): void {
    const priority = token.priority === 'priority' ? 'normal' : 'priority';
    const reason = window.prompt(`Reason for ${priority} priority:`)?.trim();
    if (!reason) return;
    this.api.updatePriority(token.id, priority, reason).subscribe(() => this.refresh());
  }

  saveSetting(setting: AppSetting): void {
    this.api.saveSetting(setting.key, setting.value).subscribe({ next: () => this.message = `${setting.key} settings saved.`, error: () => this.message = 'Unable to save settings.' });
  }

  testAnnouncement(setting: AppSetting): void {
    this.audioTestBusy = true;
    this.api.testAnnouncement(setting.value).subscribe({
      next: () => {
        this.audioTestBusy = false;
        const label = setting.value['voice_mode'] === 'offline_neural' ? 'Offline neural' : setting.value['voice_mode'] === 'offline' ? 'Basic offline' : 'Automatic';
        this.message = `${label} voice test queued on the server audio output.`;
      },
      error: (error) => {
        this.audioTestBusy = false;
        this.message = error?.error?.detail || 'Unable to test the audio voice.';
      },
    });
  }

  changePassword(): void {
    if (this.passwordForm.next !== this.passwordForm.confirm) {
      this.message = 'New password confirmation does not match.';
      return;
    }
    if (this.passwordForm.next.length < 10) {
      this.message = 'New password must contain at least 10 characters.';
      return;
    }
    this.passwordBusy = true;
    this.api.changePassword(this.passwordForm.current, this.passwordForm.next).subscribe({
      next: () => {
        this.passwordBusy = false;
        this.passwordForm = { current: '', next: '', confirm: '' };
        this.message = 'Password changed. Other signed-in sessions were closed.';
      },
      error: (error) => {
        this.passwordBusy = false;
        this.message = error?.error?.detail || 'Could not change password.';
      },
    });
  }

  loadSettings(): void {
    if (this.hasPermission('settings.manage')) {
      this.api.settings().subscribe((settings) => {
        this.settings = settings.map((setting) => setting.key === 'announcement' ? {
          ...setting,
          value: { voice_mode: 'auto', cache_max_files: 40, ...setting.value },
        } : setting);
      });
    }
    if (this.hasPermission('holidays.view') || this.hasPermission('holidays.manage')) {
      this.api.holidays().subscribe((items) => this.holidays = items);
    }
    if (this.hasPermission('devices.view') || this.hasPermission('devices.manage')) {
      this.api.devices().subscribe((items) => this.devices = items);
    }
    if (this.hasPermission('sms.view')) {
      this.api.smsMessages().subscribe((items) => this.smsMessages = items);
    }
  }

  createHoliday(): void {
    if (!this.newHoliday.holiday_date || !this.newHoliday.name.trim()) return;
    this.api.createHoliday(this.newHoliday).subscribe({
      next: (item) => { this.holidays = [...this.holidays, item].sort((a, b) => a.holiday_date.localeCompare(b.holiday_date)); this.newHoliday = { holiday_date: '', name: '' }; },
      error: (error) => this.message = error?.error?.detail || 'Could not add holiday.',
    });
  }

  createDevice(): void {
    if (!this.newDevice.name.trim()) return;
    this.api.createDevice(this.newDevice).subscribe({
      next: (created) => {
        this.devices = [...this.devices, created.device];
        this.message = `Device created. Save this client key now: ${created.client_key}`;
        this.newDevice.name = '';
      },
      error: (error) => this.message = error?.error?.detail || 'Could not create device.',
    });
  }

  loadAppointments(): void {
    if (this.hasPermission('appointments.view')) {
      this.api.appointments().subscribe({
        next: (items) => this.appointments = items,
        error: (error) => this.message = error?.error?.detail || 'Could not load appointments.',
      });
    }
    if (this.hasPermission('patients.view')) this.searchPatients();
    if (this.hasPermission('schedule.view')) {
      this.api.scheduleSlots().subscribe({
        next: (items) => this.allAppointmentSlots = items.filter((item) => new Date(item.ends_at).getTime() > Date.now()),
      });
    }
    if (this.appointmentDoctorId) this.loadAppointmentSlots();
  }

  searchPatients(): void {
    this.api.patients(this.patientSearch.trim()).subscribe({
      next: (items) => this.patients = items,
      error: (error) => this.message = error?.error?.detail || 'Could not search patients.',
    });
  }

  createPatientRecord(): void {
    if (this.newPatient.name.trim().length < 2) {
      this.message = 'Patient name must contain at least 2 characters.';
      return;
    }
    this.api.createPatient({
      name: this.newPatient.name.trim(), mobile: this.newPatient.mobile.trim(),
      title: this.newPatient.title || null, sex: this.newPatient.sex || null,
    }).subscribe({
      next: (patient) => {
        this.patients = [patient, ...this.patients];
        this.appointmentForm.patient_id = patient.id;
        this.newPatient = { name: '', mobile: '', title: '', sex: '' };
        this.message = `${patient.patient_number} registered.`;
      },
      error: (error) => this.message = error?.error?.detail || 'Could not register patient.',
    });
  }

  loadAppointmentSlots(): void {
    this.appointmentForm.slot_id = '';
    if (!this.appointmentDoctorId || !this.hasPermission('schedule.view')) {
      this.appointmentSlots = [];
      return;
    }
    this.api.scheduleSlots(this.appointmentDoctorId).subscribe({
      next: (items) => this.appointmentSlots = items.filter((item) => new Date(item.ends_at).getTime() > Date.now()),
      error: (error) => this.message = error?.error?.detail || 'Could not load appointment slots.',
    });
  }

  createAppointmentRecord(): void {
    if (!this.appointmentForm.patient_id || !this.appointmentDoctorId || !this.appointmentForm.slot_id) {
      this.message = 'Select a patient, doctor and available slot.';
      return;
    }
    this.api.createAppointment({
      patient_id: this.appointmentForm.patient_id,
      doctor_id: this.appointmentDoctorId,
      slot_id: this.appointmentForm.slot_id,
      reason: this.appointmentForm.reason || null,
      notes: this.appointmentForm.notes || null,
    }).subscribe({
      next: (appointment) => {
        this.appointments = [appointment, ...this.appointments];
        this.appointmentForm = { patient_id: '', slot_id: '', reason: '', notes: '' };
        this.message = `${appointment.appointment_number} scheduled.`;
      },
      error: (error) => this.message = error?.error?.detail || 'Could not schedule appointment.',
    });
  }

  appointmentPatient(patientId: string): Patient | undefined { return this.patients.find((item) => item.id === patientId); }
  appointmentDoctor(doctorId: string): Doctor | undefined { return this.doctors.find((item) => item.id === doctorId); }
  appointmentSlot(slotId: string): ScheduleSlot | undefined { return this.appointmentSlots.find((item) => item.id === slotId); }
  slotsForDoctor(doctorId: string): ScheduleSlot[] { return this.allAppointmentSlots.filter((item) => item.doctor_id === doctorId); }

  updateAppointmentRecord(appointment: Appointment, action: 'confirm' | 'cancel'): void {
    const reason = action === 'confirm' ? 'Attendance confirmed by reception' : window.prompt('Cancellation reason:')?.trim();
    if (!reason) return;
    this.api.updateAppointment(appointment.id, action, reason).subscribe({
      next: (updated) => this.appointments = this.appointments.map((item) => item.id === updated.id ? updated : item),
      error: (error) => this.message = error?.error?.detail || `Could not ${action} appointment.`,
    });
  }

  rescheduleAppointment(appointment: Appointment): void {
    const slotId = this.rescheduleSlots[appointment.id];
    if (!slotId) {
      this.message = 'Select a replacement slot first.';
      return;
    }
    this.api.updateAppointment(appointment.id, 'reschedule', 'Rescheduled by reception', slotId).subscribe({
      next: (updated) => {
        this.appointments = this.appointments.map((item) => item.id === updated.id ? updated : item);
        delete this.rescheduleSlots[appointment.id];
        this.message = `${updated.appointment_number} rescheduled.`;
      },
      error: (error) => this.message = error?.error?.detail || 'Could not reschedule appointment.',
    });
  }

  checkInAppointment(appointment: Appointment): void {
    this.api.checkInAppointment(appointment.id).subscribe({
      next: (token) => {
        appointment.status = 'checked_in';
        this.message = `${token.token_number} created and added to the live queue.`;
        this.printSlip(token);
      },
      error: (error) => this.message = error?.error?.detail || 'Could not check in appointment.',
    });
  }

  reportEntries(group?: Record<string, number>): [string, number][] { return Object.entries(group || {}).sort((a, b) => b[1] - a[1]); }

  canAction(token: QueueToken, action: string): boolean {
    if (!this.hasPermission('queue.action')) return false;
    const states: Record<string, string[]> = { start: ['called', 'recalled'], complete: ['in_progress'], skip: ['called', 'recalled'], recall: ['skipped', 'called', 'recalled'], no_show: ['called', 'recalled', 'skipped'], cancel: ['waiting', 'skipped', 'in_progress'] };
    return states[action]?.includes(token.status) || false;
  }

  refresh(): void {
    this.isRefreshing = true;
    if (this.view === 'display') {
      if (!this.selectedWaitingRoom) { this.isRefreshing = false; return; }
      this.api.display(this.selectedWaitingRoom).subscribe({
        next: (state) => { this.displayState = state; this.speakDisplay(state); this.markSynced(); },
        error: () => this.markOffline(),
      });
      return;
    }
    if (this.view !== 'reception' && this.view !== 'doctor') { this.isRefreshing = false; return; }
    if (!this.selectedDoctorId) {
      this.tokens = [];
      this.isRefreshing = false;
      return;
    }
    this.api.listTokens(this.selectedDoctorId).subscribe({
      next: (tokens) => { this.tokens = tokens; this.markSynced(); },
      error: () => this.markOffline(),
    });
  }

  dismissMessage(): void { this.message = ''; }

  private markSynced(): void {
    this.dataStatus = 'online';
    this.lastSyncedAt = new Date();
    this.isRefreshing = false;
  }

  private markOffline(): void {
    this.dataStatus = 'offline';
    this.isRefreshing = false;
  }

  private afterCall(token: QueueToken): void {
    this.message = `${token.token_number} — ${token.patient_name} called to room ${token.room_number}.`;
    this.busy = false;
    this.refresh();
  }

  private connectRealtime(): void {
    if (!this.selectedWaitingRoom) return;
    this.realtimeSubscription?.unsubscribe();
    this.realtimeSubscription = this.realtime.connect(this.selectedWaitingRoom).subscribe((event) => {
      if (event.type === 'patient.called') {
        // Fetch this display's room-specific queue while retaining the global call.
        this.refresh();
        return;
      }
      if (!event.display) return;
      this.displayState = event.display;
      this.speakDisplay(event.display);
    });
  }

  realtimeLabel(): string {
    return ({ connected: 'Realtime connected', connecting: 'Connecting realtime', recovering: 'Reconnecting', offline: 'Polling fallback' })[this.realtimeStatus];
  }

  serviceLabel(category: string): string {
    return this.lookupOptions.find((item) => item.category === 'service_category' && item.value === category)?.label || category;
  }

  private speakDisplay(state: DisplayState): void {
    // Audio is played centrally by the backend PC connected to the hospital PA.
    // The display only tracks the latest event; no browser/device sound is used.
    if (state.current) this.lastSpokenTokenId = state.current.id;
  }
}
