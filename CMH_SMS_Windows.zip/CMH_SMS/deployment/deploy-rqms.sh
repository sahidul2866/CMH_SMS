#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

readonly ACCOUNT_HOME="${HOME:?HOME is not set}"
readonly RELEASE_ZIP="${1:-$ACCOUNT_HOME/rqms-release.zip}"
readonly APP_ROOT="$ACCOUNT_HOME/rqms-app"
readonly DOC_ROOT="$ACCOUNT_HOME/public_html/rqms"
readonly APP_ENV="$ACCOUNT_HOME/.cmh-sms.env"
readonly STAMP="$(date +%Y%m%d-%H%M%S)"
readonly STAGE="$ACCOUNT_HOME/.rqms-stage-$STAMP"
readonly APP_BACKUP="$ACCOUNT_HOME/rqms-app-backup-$STAMP"
readonly DOC_BACKUP="$ACCOUNT_HOME/rqms-docroot-backup-$STAMP"
readonly PUBLIC_URL="https://rqms.digidrivetechnology.com"

log() { printf '\n\033[1;34m==> %s\033[0m\n' "$1"; }
fail() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }
cleanup() {
  if [ -d "$STAGE" ]; then
    find "$STAGE" -mindepth 1 -delete 2>/dev/null || true
    rmdir "$STAGE" 2>/dev/null || true
  fi
}
trap cleanup EXIT

set_env() {
  key="$1"
  value="$2"
  file="$3"
  if grep -q "^${key}=" "$file"; then
    sed -i "s#^${key}=.*#${key}=${value}#" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$file"
  fi
}

log "Preflight"
[ "$ACCOUNT_HOME" = "/home/digidriv" ] || fail "Unexpected account home: $ACCOUNT_HOME"
[ -f "$RELEASE_ZIP" ] || fail "Missing release ZIP: $RELEASE_ZIP"
[ -f "$APP_ENV" ] || fail "Missing production environment: $APP_ENV"
[ -d "$ACCOUNT_HOME/public_html" ] || fail "Missing cPanel public_html."
command -v unzip >/dev/null 2>&1 || fail "unzip is unavailable."
command -v curl >/dev/null 2>&1 || fail "curl is unavailable."
for required in backend/passenger_wsgi.py backend/requirements.txt backend/alembic.ini backend/app/main.py frontend/dist/cmh-smart-serial/browser/index.html; do
  unzip -Z1 "$RELEASE_ZIP" | awk -v item="$required" '$0==item{found=1} END{exit !found}' || fail "Release ZIP missing $required"
done

PYTHON_BIN=""
PYTHON_CANDIDATES="$(find -L "$ACCOUNT_HOME/virtualenv" -maxdepth 9 \( -type f -o -type l \) -path '*/bin/python*' 2>/dev/null | sort || true)"
while IFS= read -r candidate; do
  [ -n "$candidate" ] || continue
  case "$candidate" in
    *rqms*|*cmh_sms*|*cmh-sms*) [ -x "$candidate" ] && PYTHON_BIN="$candidate" && break ;;
  esac
done <<PYTHON_PATHS
$PYTHON_CANDIDATES
PYTHON_PATHS
[ -n "$PYTHON_BIN" ] || fail "No dedicated RQMS Python environment found. Create cPanel Setup Python App with application root rqms-app/backend."
printf 'Using Python: %s\n' "$PYTHON_BIN"

log "Preparing complete application"
mkdir "$STAGE"
unzip -q "$RELEASE_ZIP" -d "$STAGE"
cp "$APP_ENV" "$STAGE/backend/.env"
chmod 600 "$STAGE/backend/.env"
set_env CMH_SMS_ENVIRONMENT production "$STAGE/backend/.env"
set_env CMH_SMS_ALLOWED_HOSTS rqms.digidrivetechnology.com "$STAGE/backend/.env"
set_env CMH_SMS_PUBLIC_HTTPS true "$STAGE/backend/.env"
set_env CMH_SMS_COOKIE_SECURE true "$STAGE/backend/.env"
set_env CMH_SMS_CORS_ORIGINS '' "$STAGE/backend/.env"
set_env CMH_SMS_AUDIO_ENABLED false "$STAGE/backend/.env"
set_env CMH_SMS_FRONTEND_DIST "$APP_ROOT/frontend/dist/cmh-smart-serial/browser" "$STAGE/backend/.env"

log "Installing dependencies"
"$PYTHON_BIN" -m pip install --disable-pip-version-check -r "$STAGE/backend/requirements.txt"
"$PYTHON_BIN" -m compileall -q "$STAGE/backend/app" "$STAGE/backend/passenger_wsgi.py"

log "Applying database migrations and seed"
(
  set -a
  # shellcheck disable=SC1091
  source "$STAGE/backend/.env"
  set +a
  cd "$STAGE/backend"
  current_revision="$("$PYTHON_BIN" -m alembic current 2>/dev/null | awk 'NF { value=$1 } END { print value }')"
  head_revision="$("$PYTHON_BIN" -m alembic heads 2>/dev/null | awk 'NF { value=$1 } END { print value }')"
  if [ -n "$current_revision" ] && [ "$current_revision" = "$head_revision" ]; then
    printf 'Database already at Alembic head %s; migrations skipped.\n' "$head_revision"
  else
    "$PYTHON_BIN" -m alembic upgrade head
  fi
  "$PYTHON_BIN" -m app.seed
)

log "Creating Passenger document root"
mkdir "$STAGE/document-root"
{
  printf 'PassengerEnabled On\n'
  printf 'PassengerAppRoot "%s/backend"\n' "$APP_ROOT"
  printf 'PassengerBaseURI "/"\n'
  printf 'PassengerAppType wsgi\n'
  printf 'PassengerStartupFile passenger_wsgi.py\n'
  printf 'PassengerPython "%s"\n' "$PYTHON_BIN"
  printf 'PassengerAppLogFile "%s/rqms-passenger.log"\n' "$ACCOUNT_HOME"
} > "$STAGE/document-root/.htaccess"
find "$STAGE/backend" "$STAGE/frontend" -type d -exec chmod 755 {} \;
find "$STAGE/backend" "$STAGE/frontend" -type f -exec chmod 644 {} \;
chmod 600 "$STAGE/backend/.env"
chmod 644 "$STAGE/document-root/.htaccess"

log "Backing up current deployment"
[ -d "$APP_ROOT" ] && mv "$APP_ROOT" "$APP_BACKUP"
[ -d "$DOC_ROOT" ] && mv "$DOC_ROOT" "$DOC_BACKUP"

log "Publishing RQMS"
mkdir "$APP_ROOT"
mv "$STAGE/backend" "$APP_ROOT/backend"
mv "$STAGE/frontend" "$APP_ROOT/frontend"
mv "$STAGE/document-root" "$DOC_ROOT"
mkdir -p "$APP_ROOT/backend/tmp"
touch "$APP_ROOT/backend/tmp/restart.txt"

log "Checking production"
health_status=""
for attempt in 1 2 3 4 5; do
  health_status="$(curl -L -sS -o /dev/null --max-time 20 -w '%{http_code}' "$PUBLIC_URL/api/v1/health" || true)"
  [ "$health_status" = "200" ] && break
  sleep 3
done
page_status="$(curl -L -sS -o /dev/null --max-time 30 -w '%{http_code}' "$PUBLIC_URL/" || true)"
[ "$health_status" = "200" ] || fail "RQMS health returned HTTP ${health_status:-ERR}. Check $ACCOUNT_HOME/rqms-passenger.log"
[ "$page_status" = "200" ] || fail "RQMS frontend returned HTTP ${page_status:-ERR}."

printf '\nRQMS deployment successful: %s\n' "$PUBLIC_URL"
[ -d "$APP_BACKUP" ] && printf 'Application backup: %s\n' "$APP_BACKUP"
[ -d "$DOC_BACKUP" ] && printf 'Document-root backup: %s\n' "$DOC_BACKUP"
